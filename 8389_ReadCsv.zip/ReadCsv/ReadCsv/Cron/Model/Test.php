<?php
namespace ReadCsv\Cron\Model;

use Magento\Framework\Exception\FileSystemException;

class Test
{   
    
     /**
     * @var \Magento\Framework\Filesystem\Driver\File
     */
    protected $file;
    /**
     * @var \Magento\Framework\File\Csv
     */
    protected $csv;
    /**
     * @var \Psr\Log\LoggerInterface
     */
    protected $logger;
    /**
     * @var \Magento\Framework\Module\Dir\Reader
     */
    protected $directoryList;

    /**
     * @var \Magento\Framework\Filesystem\DirectoryList
     */
    protected $_dir;

    /**
     * @var StockRegistryInterface
     */
    protected $stockRegistry;  
    
    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Magento\Framework\Filesystem\Driver\File        $file
     * @param \Magento\Framework\File\Csv                      $csv
     * @param \Psr\Log\LoggerInterface                         $logger
     * @param array                                            $data
     */
    public function __construct(
        \Magento\Framework\Filesystem\Driver\File $file,
        \Magento\Framework\File\Csv $csv,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\Module\Dir\Reader $directoryList,
        \Magento\Framework\Filesystem\DirectoryList $dir,
        \Magento\CatalogInventory\Api\StockRegistryInterface $stockRegistry
    ) {
        $this->file = $file;
        $this->csv = $csv;
        $this->logger = $logger;
        $this->directoryList = $directoryList;
        $this->_dir = $dir;
        $this->stockRegistry = $stockRegistry;
    }
 
    public function getCsvData()
    {
    
        try {
            $data = file_get_contents($this->_dir->getRoot().'/var/import_history/OPT在庫データ.csv');
            $lines = explode(PHP_EOL, $data);
            $array = array();
            foreach ($lines as $line) {
                $array[] = str_getcsv($line);
            }
            foreach ($array as $item) {
                try {
                    if ($item[0]) {
                        $sku = $item[0];
                        $stockItem = $this->stockRegistry->getStockItemBySku($sku);
                        $stockItem->setQty((int)$item[1]);
                        $stockItem->setIsInStock((bool)$item[1]); // this line
                        $this->stockRegistry->updateStockItemBySku($sku, $stockItem);
                    } else {
                        continue;
                    } 
                } catch (\Exception $e) {
                    echo $e->getMessage();
                    continue;
                }
            }  
        } catch (FileSystemException $e) {
            die($e->getMessage());
        }
    }
}
