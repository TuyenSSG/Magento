<?php

namespace ReadCsv\Cron\Controller\Test;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;

/**
 * Class Cart
 * @package Mageplaza\AbandonedCart\Controller\Checkout
 */
class Test extends Action
{

    /**
     * @var \Magento\Framework\Filesystem\Driver\File
     */
    protected $file;
    /**
     * @var \Magento\Framework\File\Csv
     */
    protected $csv;
    /**
     * @var \Psr\Log\LoggerInterface
     */
    protected $logger;
    /**
     * @var \Magento\Framework\Module\Dir\Reader
     */
    protected $directoryList;

    /**
     * @var \Magento\Framework\Filesystem\DirectoryList
     */
    protected $_dir;

    protected $productRepository;

    /**
     * @var StockRegistryInterface
     */
    protected $stockRegistry;  

    /**
     * constructor.
     *
     * @param \Magento\Framework\App\Action\Context $context
     */
    public function __construct(
        Context $context,
        \Magento\Framework\Filesystem\Driver\File $file,
        \Magento\Framework\File\Csv $csv,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\Module\Dir\Reader $directoryList,
        \Magento\Framework\Filesystem\DirectoryList $dir,
        \Magento\CatalogInventory\Api\StockRegistryInterface $stockRegistry
    ) {
        $this->file = $file;
        $this->csv = $csv;
        $this->logger = $logger;
        $this->directoryList = $directoryList;
        $this->_dir = $dir;
        $this->stockRegistry = $stockRegistry;

        parent::__construct($context);
    }

    /**
     * Recovery cart by cart link
     *
     * @return \Magento\Framework\App\ResponseInterface
     */
    public function execute()
    {
    
        try {
            $data = file_get_contents($this->_dir->getRoot().'/var/import_history/OPT在庫データ.csv');
            $lines = explode(PHP_EOL, $data);
            $array = array();
            foreach ($lines as $line) {
                $array[] = str_getcsv($line);
            }
                 // var_dump($array);die(); 
            foreach ($array as $item) {
                try {
                    if ($item[0]) {
                        $sku = $item[0];
                        // $product = $this->productRepository->get($item[0]);
                        $stockItem = $this->stockRegistry->getStockItemBySku($sku);
                        $stockItem->setQty((int)$item[1]);
                        $stockItem->setIsInStock((bool)$item[1]); // this line
                        $this->stockRegistry->updateStockItemBySku($sku, $stockItem);
                        // echo $productModel->getId();
                    } else {
                        continue;
                    } 
                } catch (\Exception $e) {
                    echo $e->getMessage();
                    continue;
                }
            }  
        } catch (FileSystemException $e) {
            die($e->getMessage());
        }
    }
}
